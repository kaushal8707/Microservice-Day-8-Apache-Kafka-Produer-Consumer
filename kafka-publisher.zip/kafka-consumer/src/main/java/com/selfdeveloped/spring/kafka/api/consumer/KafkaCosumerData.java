package com.selfdeveloped.spring.kafka.api.consumer;
import java.util.ArrayList;
import java.util.List;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.selfdeveloped.spring.kafka.api.model.User;
@Component
public class KafkaCosumerData {
	
	public List<String> messages=new ArrayList();
	public User userFromTopic=null;
	
	@KafkaListener(groupId = "TestTopic-1", topics = "TestTopic", containerFactory = "kaListenerContainerFactory")
	public List<String> getMsgsFromTopic(String data)
	{
		messages.add(data);
		return messages;
	}
	
	@KafkaListener(groupId = "TestTopic-2", topics = "TestTopic", containerFactory = "userKaListenerContainerFactory")
	public User getJsonMsgsFromTopic(User user)
	{
		userFromTopic=user;
		return userFromTopic;
	}

}
